class CkanException(Exception):
    pass

class EmptyRevisionException(CkanException):
    pass

class CkanUrlException(Exception):
    pass
