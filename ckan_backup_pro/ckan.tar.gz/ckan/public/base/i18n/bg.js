{
  "": {
    "domain": "ckan",
    "lang": "bg",
    "plural-forms": "nplurals=2; plural=(n != 1);"
  },
  "Cancel": [
    null,
    "Отказ"
  ],
  "Edit": [
    null,
    "Редакция"
  ],
  "Follow": [
    null,
    "Следвай"
  ],
  "Loading...": [
    null,
    "Зареждане...."
  ],
  "URL": [
    null,
    "URL"
  ],
  "Upload a file": [
    null,
    "Качване на файл"
  ]
}