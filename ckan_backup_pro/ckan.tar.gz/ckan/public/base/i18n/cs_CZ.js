{
  "": {
    "domain": "ckan",
    "lang": "cs_CZ",
    "plural-forms": "nplurals=3; plural=(n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2;"
  },
  "An Error Occurred": [
    null,
    "Nastala chyba"
  ],
  "Are you sure you want to perform this action?": [
    null,
    "Jste si jistí, že chcete provést tuto akci?"
  ],
  "Cancel": [
    null,
    "Zrušit"
  ],
  "Confirm": [
    null,
    "Potvrdit"
  ],
  "Edit": [
    null,
    "Upravit"
  ],
  "Failed to load data API information": [
    null,
    "Pokus o získání informací pomocí API selhal"
  ],
  "Follow": [
    null,
    "Sledovat"
  ],
  "Hide": [
    null,
    "Skrýt"
  ],
  "Input is too short, must be at least one character": [
    null,
    "Zadaný vstup je příliš krátký, musíte zadat alespoň jeden znak"
  ],
  "Loading...": [
    null,
    "Nahrávám ..."
  ],
  "No matches found": [
    null,
    "Nenalezena žádná shoda"
  ],
  "Please Confirm Action": [
    null,
    "Prosím potvrďte akci"
  ],
  "Resource uploaded": [
    null,
    "Zdroj nahrán"
  ],
  "Show more": [
    null,
    "Ukázat více"
  ],
  "Start typing…": [
    null,
    "Začněte psát..."
  ],
  "There are unsaved modifications to this form": [
    null,
    "Tento formulář obsahuje neuložené změny"
  ],
  "There is no API data to load for this resource": [
    null,
    "Tento zdroj neobsahuje žádná data, která lze poskytnou přes API"
  ],
  "URL": [
    null,
    "URL"
  ],
  "Unable to authenticate upload": [
    null,
    "Nastala chyba autentizace při nahrávání dat"
  ],
  "Unable to get data for uploaded file": [
    null,
    "Nelze získat data z nahraného souboru"
  ],
  "Unable to upload file": [
    null,
    "Nelze nahrát soubor"
  ],
  "Unfollow": [
    null,
    "Přestat sledovat"
  ],
  "Upload a file": [
    null,
    "Nahrát soubor"
  ],
  "You are uploading a file. Are you sure you want to navigate away and stop this upload?": [
    null,
    "Právě nahráváte soubor. Jste si opravdu jistí, že chcete tuto stránku opustit a ukončit tak nahrávání?"
  ],
  "show less": [
    null,
    "ukázat méně"
  ],
  "show more": [
    null,
    "ukázat více"
  ]
}