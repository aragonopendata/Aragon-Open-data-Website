{
  "": {
    "domain": "ckan",
    "lang": "es_AR",
    "plural-forms": "nplurals=2; plural=(n != 1);"
  }
}