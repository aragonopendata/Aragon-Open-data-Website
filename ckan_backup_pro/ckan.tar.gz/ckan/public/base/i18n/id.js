{
  "": {
    "domain": "ckan",
    "lang": "id",
    "plural-forms": "nplurals=1; plural=0;"
  },
  "Cancel": [
    null,
    "Batal"
  ],
  "Edit": [
    null,
    "Edit"
  ],
  "Follow": [
    null,
    "Ikuti"
  ],
  "Loading...": [
    null,
    "Memuat..."
  ],
  "URL": [
    null,
    "URL"
  ],
  "Unfollow": [
    null,
    "Tidak ikuti"
  ],
  "Upload a file": [
    null,
    "Unggah file"
  ]
}