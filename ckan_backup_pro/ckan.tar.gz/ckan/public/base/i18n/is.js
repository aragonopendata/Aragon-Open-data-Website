{
  "": {
    "domain": "ckan",
    "lang": "is",
    "plural-forms": "nplurals=2; plural=(n != 1);"
  },
  "An Error Occurred": [
    null,
    "Villa kom upp"
  ],
  "Are you sure you want to perform this action?": [
    null,
    "Ertu viss um að þú viljir framkvæma þessa aðgerð?"
  ],
  "Cancel": [
    null,
    "Hætta við"
  ],
  "Confirm": [
    null,
    "Staðfesta"
  ],
  "Edit": [
    null,
    "Breyta"
  ],
  "Failed to load data API information": [
    null,
    "Villa kom upp við að sækja upplýsingar um API gögn"
  ],
  "Follow": [
    null,
    "Fylgjast með"
  ],
  "Hide": [
    null,
    "Fela"
  ],
  "Input is too short, must be at least one character": [
    null,
    "Of stutt, verður að vera í það minnsta einn stafur"
  ],
  "Loading...": [
    null,
    "Hleð..."
  ],
  "No matches found": [
    null,
    "Ekkert fannst"
  ],
  "Please Confirm Action": [
    null,
    "Vinsamlegast staðfestu aðgerðina"
  ],
  "Resource uploaded": [
    null,
    "Skránni hefur verið hlaðið inn"
  ],
  "Show more": [
    null,
    "Sýna fleiri"
  ],
  "Start typing…": [
    null,
    "Sláðu inn fyrstu stafina..."
  ],
  "There are unsaved modifications to this form": [
    null,
    "Það eru óvistaðar breytingar í þessu formi"
  ],
  "There is no API data to load for this resource": [
    null,
    "Það eru engin API gögn sem er hægt að hlaða inn fyrir þetta skrá"
  ],
  "URL": [
    null,
    "Vefslóð"
  ],
  "Unable to authenticate upload": [
    null,
    "Ekki fékst heimild til að hlaða inn skrá"
  ],
  "Unable to get data for uploaded file": [
    null,
    "Ekki tókst að sækja gögn úr skránni sem þú hlóðst inn"
  ],
  "Unable to upload file": [
    null,
    "Ekki tókst að hlaða inn skrá"
  ],
  "Unfollow": [
    null,
    "Hætta að fylgjast með"
  ],
  "Upload a file": [
    null,
    "Hlaða inn skrá"
  ],
  "show less": [
    null,
    "sýna færri"
  ],
  "show more": [
    null,
    "sýna fleiri"
  ]
}