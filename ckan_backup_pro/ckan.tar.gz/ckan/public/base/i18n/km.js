{
  "": {
    "domain": "ckan",
    "lang": "km",
    "plural-forms": "nplurals=1; plural=0;"
  }
}