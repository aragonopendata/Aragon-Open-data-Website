{
  "": {
    "domain": "ckan",
    "lang": "sk",
    "plural-forms": "nplurals=3; plural=(n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2;"
  },
  "Cancel": [
    null,
    "Zrušiť"
  ],
  "Edit": [
    null,
    "Upraviť"
  ],
  "Follow": [
    null,
    "Odoberať"
  ],
  "Loading...": [
    null,
    "Prebieha načítavanie..."
  ],
  "URL": [
    null,
    "URL"
  ],
  "Unfollow": [
    null,
    "Prestať odoberať"
  ],
  "Upload a file": [
    null,
    "Nahrať súbor"
  ]
}