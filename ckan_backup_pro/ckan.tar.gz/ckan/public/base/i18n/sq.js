{
  "": {
    "domain": "ckan",
    "lang": "sq",
    "plural-forms": "nplurals=2; plural=(n != 1);"
  },
  "Edit": [
    null,
    "Modifikoni"
  ],
  "URL": [
    null,
    "URL"
  ]
}