	// mover la cabecera superior al hacer scroll
$(function(){
	$(window).scroll(function() {
		$html = $("html");
		
		//Esto se debe de modificar ya que todos los navegadores lo pueden hacer de modo diferente
		/*if($html.hasClass('webkit')){
			var scrollTop = $("body")[0].scrollTop;
		}else if($html.hasClass('firefox')){
			var scrollTop = $("html")[0].scrollTop;
		}else{
			var scrollTop = $(document).scrollTop();
			
			//var scrollTop = $("body")[0].scrollTop;
			//var scrollTop = $("html")[0].scrollTop;
		}*/

		
		//Con window creo que pilla La barra de scroll ya que el lÃ­mite esta en 754 con lo que esta barra tiene 14 pixeles
		//if (($( window ).width()>754) && ( scrollTop >= 160)){
		if (($( window ).width()>754) && ($(document).scrollTop() >= 160)){
			$('body').addClass('mini');
		}
		else{
			$('body').removeClass('mini');
		}
		/*if( scrollTop < 160 ){
			$('body').removeClass('mini');
		}else{
			$('body').addClass('mini');
		}*/
	});
	$("body").trigger('scroll');
});

function refinaAutocomplete() {
	$.ui.autocomplete.prototype._renderItem = function( ul, item) {
		return $( "<li></li>" )
			.data( "item.autocomplete", item )
			.append( "<a href='/catalogo/" + item.valor + "'>" + item.label + "</a>" )
			.appendTo( ul );
	};	
}

function changeOrder(newOrder, destinationUrl) {
	var txtToFind = '';
	var aux = window.location.search;
	var paramStr = aux.split('?');
	for (var itemStr=0; itemStr < paramStr.length; itemStr++) {
		if (paramStr[itemStr] != "") {
			var paramList = paramStr[itemStr].split("&");
			for (var item=0; item < paramList.length; item++) {
				var currentItem = paramList[item].split("=");
				if ((currentItem[0].toLowerCase() == "q")  && (currentItem.length > 1)) {
					txtToFind = "q=" + currentItem[1];
				}
			}
		}
	}
   
	if (destinationUrl) {
		window.location = currentUrl + "?" + txtToFind + "&" + newOrder ;		
	} else {
		if (currentUrl) {
			 // mirar si tiene ?
			if (currentUrl.indexOf('?') != -1) {
				window.location = currentUrl + "&" + txtToFind + "&" + newOrder ;
			} else {
				window.location = currentUrl + "?" + txtToFind + "&" + newOrder;
			}
		}
	}
}


function tryToSelectOrder(orderType) {
	alert(orderType);
}

function tryToSelectItem(obj, txt) {
	if (obj != null) {
		for (k =0 ; k < obj.length; k++) {
			if (obj[k].value == txt) {
				obj[k].selected = true;
			}
		}
	}
}

function changeHomerLabels(valorLang) {
	$("#labelBuscarHomer_es").addClass("oculto");
	$("#labelIdiomaHomer_es").addClass("oculto");
	$("#labelBuscarHomer_en").addClass("oculto");
	$("#labelIdiomaHomer_en").addClass("oculto");
	$("#labelBuscarHomer_fr").addClass("oculto");
	$("#labelIdiomaHomer_fr").addClass("oculto");
	$("#labelBuscarHomer_it").addClass("oculto");
	$("#labelIdiomaHomer_it").addClass("oculto");
	$("#labelBuscarHomer_el").addClass("oculto");
	$("#labelIdiomaHomer_el").addClass("oculto");
	$("#labelBuscarHomer_sl").addClass("oculto");
	$("#labelIdiomaHomer_sl").addClass("oculto");
	$("#labelBuscarHomer_sr").addClass("oculto");
	$("#labelIdiomaHomer_sr").addClass("oculto");

	$("#labelBuscarHomer_" + valorLang).toggleClass("oculto");
	$("#labelIdiomaHomer_" + valorLang).toggleClass("oculto");
}

$(document).ready(function() {
	refinaAutocomplete();

      //al inicio, quitarlo si tiene valor porque lo autorrellene el navegador de otras visitas	
  if (($("#cajaDeBusqInput").val() != "")) {
    $("#cajaDeBusqInput").css("background", "#FFFFFF");
  }
  
  $("#cajaDeBusqInput").on('blur', function() {
    if (($("#cajaDeBusqInput").val() != "")) {
      $("#cajaDeBusqInput").css("background", "#FFFFFF");
    }
  });

	var config  = {
		disable_search: true
	};

	var fOnChgChosen_changeLangHomer = function onChgChosen_changeLangHomer() {
		var idx = $("#langHOMERFilter")[0].selectedIndex;
		var valorLang = $("#langHOMERFilter")[0][idx].value;

		changeHomerLabels(valorLang);
		return false;
	}
	
	var fOnChgChosen = function onChgChosen() {
		var urlToGo = "/catalogo";
		var idxBBDD = $("#bbddFilter")[0].selectedIndex;
		if (idxBBDD != 0) {
			urlToGo += "/base-datos/" + $("#bbddFilter")[0][idxBBDD].value;
		}
		var idxTema = $("#temaFilter")[0].selectedIndex;
		if (idxTema != 0) {
			urlToGo += "/" + $("#temaFilter")[0][idxTema].value;
		}
		var idxTipo = $("#tipoFilter")[0].selectedIndex;
		if (idxTipo != 0) {
			urlToGo += "/" + $("#tipoFilter")[0][idxTipo].value;
		}
		window.location = urlToGo;
		return false;
	}

	var fOnChgChosen_toggle = function onChgChosen_toggle() {
		var idxTipo = $("#tipoBusquedaFilter")[0].selectedIndex;		
		if ($("#tipoBusquedaFilter")[0][idxTipo].value == "zonaSPARQL") {
			window.location = "/portal/cliente-sparql";
		} else if ($("#tipoBusquedaFilter")[0][idxTipo].value == "zonaAPI") {
			window.location = "/portal/desarrolladores/api-ckan";
		}
		else if($("#tipoBusquedaFilter")[0][idxTipo].value == "zonaBBDD"){
			//modicamos para que las options se queden seleccionadas
			/*$('#tipoBusquedaFilter').find('option:selected').removeAttr('selected');
			$('#tipoBusquedaFilter option[value=zonaBBDD]').attr('selected',true);
			$('#tipoBusquedaFilter_chosen .chosen-single span').text('Base de datos');*/
			tryToSelectItem($("#tipoBusquedaFilter")[0], "zonaBBDD");
			//Vamos a la url correspondiente
			window.location = "/catalogo/base-datos";
		}
		else {
			var newZone = $("#tipoBusquedaFilter")[0][idxTipo].value;
			if (newZone == "zonaInfoEstadistica") {
				window.location = "/catalogo/informacion-estadistica";
			}
			else if (newZone == "zonaTemaYTipo") {
				window.location = "/catalogo/catalogo.html";
			}
			else if (newZone == "zonaLibre") {
				tryToSelectItem($("#tipoBusquedaFilter")[0], "zonaLibre");
				window.location = "/catalogo/busqueda-libre";
			}
			else {
				toggleZona($("#tipoBusquedaFilter")[0][idxTipo].value);
			}
		}
		return false;
	}

	var currentComboEstad = null;

	var fOnChgChosen_estadistica_nivel1 = function onChgChosen_estadistica_nivel1() {
		var urlToGo = "/catalogo";

		var idxGrupo = $("#estadisNivel1_Filter")[0].selectedIndex;
		if (idxGrupo != 0) {
			urlToGo += "/tema-estadistico/" + $("#estadisNivel1_Filter")[0][idxGrupo].value;
		}
		window.location = urlToGo;
		return false;
	}

	var fOnChgChosen_estadistica_nivel2 = function onChgChosen_estadistica_nivel2() {
		var urlToGo = "/catalogo";

		if (currentComboEstad) {
			var idxGrupo = $(currentComboEstad)[0].selectedIndex;
			if (idxGrupo != 0) {
				urlToGo += "/tema-estadistico/" + $(currentComboEstad)[0][idxGrupo].value;
			} else {
				var idxGrupoNivel1 = $("#estadisNivel1_Filter")[0].selectedIndex;
				urlToGo += "/tema-estadistico/" + $("#estadisNivel1_Filter")[0][idxGrupoNivel1].value;
			}
		}
		window.location = urlToGo;
		return false;
	}

	var urlListParam  = new Array();
	if (currentUrl) {
		urlListParam = currentUrl.split("/");
		if (urlListParam.length == 3) {
			if (urlListParam[2] == "informacion-estadistica") {
					// o es info estadistica
				toggleZona("zonaInfoEstadistica");
				tryToSelectItem($("#tipoBusquedaFilter")[0], "zonaInfoEstadistica");
			}
			else if (urlListParam[2] == "base-datos") {
					// o es bbdd
				tryToSelectItem($("#tipoBusquedaFilter")[0], "zonaBBDD");
			}
			else if (urlListParam[2] == "busqueda-libre") {
					// o es búsqueda libre
				tryToSelectItem($("#tipoBusquedaFilter")[0], "zonaLibre");
			}  
			else {
					// O es tema o es tipo
				tryToSelectItem($("#temaFilter")[0], urlListParam[2]);
				tryToSelectItem($("#tipoFilter")[0], urlListParam[2]);
			}
	} else if (urlListParam.length == 4) {
				// O es tema+tipo o es tipo-estadistico/num o es base-datos/tipobbdd
			
			tryToSelectItem($("#temaFilter")[0], urlListParam[2]);
			var idxTema = $("#temaFilter")[0].selectedIndex;
			if (idxTema != 0) {
					// es tema+tipo
				tryToSelectItem($("#tipoFilter")[0], urlListParam[3]);
			}
			//alert('cargado '+urlListParam[2]+'/'+urlListParam[3]);
			if (urlListParam[2] == "busqueda-libre"){
				var txtBusqueda = utf8_decode(unescape(urlListParam[3]));
				$("#cajaDeBusqInputLibre").val(txtBusqueda);
			}

			if (urlListParam[2] == "tema-estadistico") {
				var auxTipoEstad = urlListParam[3].substr(0,2);
				var auxSubTipoEstad = urlListParam[3].substr(0,4);
				tryToSelectItem($("#estadisNivel1_Filter")[0], auxTipoEstad);
				if (auxTipoEstad.length == 2) {

					currentComboEstad = "#estadisNivel2_grp" + auxTipoEstad + "_Filter";
					var subnivelItem = $(currentComboEstad);
					if (subnivelItem) {
						tryToSelectItem(subnivelItem[0], auxSubTipoEstad);
						$(currentComboEstad + "Div").removeClass("oculto");
						subnivelItem.chosen(config).change(fOnChgChosen_estadistica_nivel2);
					}
				}
			}
			else if (urlListParam[2] == "base-datos") {
				tryToSelectItem($("#bbddFilter")[0], urlListParam[3]);
			}
			
		}

		if (urlListParam.length >= 3) {
			if (urlListParam[2] != "informacion-estadistica") {
				activateZoneTipoBusqueda(urlListParam[2]);
			}
			else if (urlListParam[2] != "base-datos") {
				activateZoneTipoBusqueda(urlListParam[2]);
			}
			else if (urlListParam[2] != "busqueda-libre") {
				activateZoneTipoBusqueda(urlListParam[2]);
			}
		} else {
			tryToSelectItem($("#tipoBusquedaFilter")[0], "zonaTemaYTipo");
			toggleZona("zonaTemaYTipo");
		}
	} else {
		tryToSelectItem($("#tipoBusquedaFilter")[0], "zonaTemaYTipo");
		toggleZona("zonaTemaYTipo");
	}

	disEnableAllItemsForm(false);

	$("#temaFilter").chosen(config).change(fOnChgChosen);
	$("#tipoFilter").chosen(config).change(fOnChgChosen);
	$("#bbddFilter").chosen(config).change(fOnChgChosen);

//	$("#tipoBusquedaFilter").chosenImage(config).change(fOnChgChosen_toggle);
	$("#tipoBusquedaFilter").chosen(config).chosenImage().change(fOnChgChosen_toggle);

	$("#langHOMERFilter").chosen(config).change(fOnChgChosen_changeLangHomer);

	$("#estadisNivel1_Filter").chosen(config).change(fOnChgChosen_estadistica_nivel1);

   $('#txtHOMER').keypress(function(event) {
        if (event.keyCode == 13) {
            submitHomer();
        }
    });

   $('#cajaDeBusqInputLibre').keypress(function(event) {
        if (event.keyCode == 13) {
            submitTxtQuery();
        }
    });

    $( "#cajaDeBusqInput" ).autocomplete({
		source:function(request, response) {
			$.ajax({
  			  url: "/catalogo/api/2/util/dataset/autocomplete?incomplete=%" + $("#cajaDeBusqInput").val() + "%",
			  dataType: "jsonp",
			  success: function (data) {
				response($.map(data.ResultSet.Result, 
					function(item)	{
						return {
							label: item.title,
							valor: item.name,
							value: item.title
						};
					}
				));
			  }			
		        })
		   },
		minLength: 1,
		open: function(event, ui) {
					$(this).autocomplete("widget").css({
						"width": 425
					});
				},
		select: function( event, item) {
			$("#cajaBusqBanner").attr("action",  "/catalogo/" + item.item.valor);
			$("#cajaDeBusqInput").val("");
			$("#cajaBusqBanner").submit();
		}
    });


    initializeDashboard();
    initializeEditor();
    loadComboboxesVistas();

    if (document.getElementById("zonaVentanaDatosDescargados1")) {
	$.ajax({
			url: "/catalogo/api/mostDownloadedDataset",
			dataType: "jsonp",
			success: function (data) {
				var htmlCode = '';
				for (var ii = 0; ii < 3; ii++) {
					htmlCode += '<div><a href="/catalogo/' + (data[ii].name) + '" title="' + (data[ii].title) + '">' + (data[ii].title) + '</a></div>';
					if (ii != 2) {
						htmlCode += '<div class="separadorVentana"></div>';
					}
				}
				$('#zonaVentanaDatosDescargados1').html(htmlCode);
			}
		     });
    }

    if (document.getElementById("zonaVentanaDatosRecientes1")) {
	$.ajax({
			url: "/catalogo/api/mostRecentDataset",
			dataType: "jsonp",
			success: function (data) {
				var htmlCode = '';
				for (var ii = 0; ii < 3; ii++) {
					htmlCode += '<div><a href="/catalogo/' + (data[ii].name) + '" title="' + (data[ii].title) + '">' + (data[ii].title) + '</a></div>';
					if (ii != 2) {
						htmlCode += '<div class="separadorVentana"></div>';
					}
				}
				$('#zonaVentanaDatosRecientes1').html(htmlCode);
			}
		     });
    }

    if (document.getElementById("numDatasets")) {
//	$.ajax({
//			url: "/catalogo/api/getDataCount",
//			dataType: "jsonp",
//			success: function (data) {
//				var htmlCodeDatasets = getContadorHTML(data[0].datasetCount);
//				var htmlCodeRecursos = getContadorHTML(data[0].resourceCount);
//				$('#numDatasets').html(htmlCodeDatasets);
//				$('#numRecursos').html(htmlCodeRecursos);
//			},
//			error: function (data) {
//				var htmlCodeDatasets = getContadorHTML(1709);
//				var htmlCodeRecursos = getContadorHTML(2724);
//				$('#numDatasets').html(htmlCodeDatasets);
//				$('#numRecursos').html(htmlCodeRecursos);
//			}
//	   });
			var htmlCodeDatasets =getContadorHTML(datasetCount);
			var htmlCodeRecursos = getContadorHTML(resourceCount);
			$('#numDatasets').html(htmlCodeDatasets);
			$('#numRecursos').html(htmlCodeRecursos);
    }

	if ($("#homerResults").html() != null) {
		doQueryHomer();
	}
});

function activateZoneTipoBusqueda(txtParam) {
	var currentUrl = window.location.toString();
	var queriedTxt = "";

	urlListParamPrev = currentUrl.split("?");

	if (urlListParamPrev.length > 1) {
		urlListParam = urlListParamPrev[1].split("&");

		for (var i = 0; i < urlListParam.length; i++) {
			var keyValue = urlListParam[i].split("=");
			switch (keyValue[0]) {
				case 'q': (keyValue[1] ? queriedTxt = decodeURI(decodeURI(keyValue[1])).replace(/\+/g, " ") : j=0); break;
			}
		}
	}

	if (txtParam == "searchHOMER") {
		tryToSelectItem($("#tipoBusquedaFilter")[0], "zonaHOMER");
		toggleZona("zonaHOMER");
	} else if (txtParam == "tema-estadistico") {
		tryToSelectItem($("#tipoBusquedaFilter")[0], "zonaInfoEstadistica");
		toggleZona("zonaInfoEstadistica");
	}
	else if (txtParam == "informacion-estadistica") {
		tryToSelectItem($("#tipoBusquedaFilter")[0], "zonaInfoEstadistica");
		toggleZona("zonaInfoEstadistica");
	}
	else if (txtParam == "base-datos") {
		tryToSelectItem($("#tipoBusquedaFilter")[0], "zonaBBDD");
		toggleZona("zonaBBDD");
		
		
		urlListParam = currentUrl.split("/");
		if (urlListParam.length==6){
			tryToSelectItem($("#bbddFilter")[0], urlListParam[5]);
		}
	}
	else if (txtParam == "busqueda-libre") {
		tryToSelectItem($("#tipoBusquedaFilter")[0], "zonaLibre");
		toggleZona("zonaLibre");
	}
	else if (queriedTxt != '') {
		tryToSelectItem($("#tipoBusquedaFilter")[0], "zonaLibre");
		toggleZona("zonaLibre");
		$("#cajaDeBusqInputLibre").val(queriedTxt);
	} else {
		tryToSelectItem($("#tipoBusquedaFilter")[0], "zonaTemaYTipo");
		toggleZona("zonaTemaYTipo");
	}
}

function toggleAllZones() {
	$("#zonaTemaYTipo").addClass("oculto");
	$("#zonaInfoEstadistica").addClass("oculto");
	$("#zonaLibre").addClass("oculto");
	$("#zonaHOMER").addClass("oculto");
	$("#zonaBBDD").addClass("oculto");
}

function toggleZona(id) {
	toggleAllZones();
	$("#" + id).toggleClass("oculto");
/*
	if (id == "zonaHOMER") {
		$("#logoHomerCabecera").removeClass("oculto");
	} else {
		$("#logoHomerCabecera").addClass("oculto");
	}*/
}

function getContadorDigit(number) {
	var htmlCode = '';
	if ((number >=0) && (number <=9)) {
		htmlCode = '<img src="/public/i/contador/' + number + '.png" alt="' + number + '">';
	}
	return htmlCode;
}

function getContadorHTML(number) {
	var htmlCode = '';
	var numDigitos = 0;
	var aux = number;
	while (aux > 9) {
		htmlCode = getContadorDigit(aux % 10) + htmlCode;
		aux = Math.floor(aux /10);
		numDigitos++;
	}
	htmlCode = getContadorDigit(aux) + htmlCode;
	numDigitos++;
	
	for (var j = numDigitos; j < 8; j++) {
		htmlCode = '<img src="/public/i/contador/0_off.png" alt="0">' + htmlCode;
	}
	
	return htmlCode;
}

function submitHomer() {
	$('form').attr('action', '/catalogo/searchHOMER');
	submitQuery();
}

function submitTxtQuery() {
	submitQuery();
}

function disEnableAllItemsForm(disEnab) {
  $('div.oculto > input').attr("disabled",disEnab);
  $('div.oculto > select').attr("disabled",disEnab);
  $('div.oculto > div > input').attr("disabled",disEnab);
  $('div.oculto > div > select').attr("disabled",disEnab);
  $('div.oculto > div > ul > li > input').attr("disabled",disEnab);
  $('div.oculto > div > ul > li > select').attr("disabled",disEnab);
  $('#tipoBusquedaFilter').attr("disabled",disEnab);
  $('form > select:hidden').attr("disabled",disEnab);
  
  if ($("#autocomplete_eurovoc")){
    $('#autocomplete_eurovoc').attr("disabled",disEnab);
  }
}

function submitQuery() {
	disEnableAllItemsForm(true);
	if (document.getElementById("tipoBusquedaFilter").value == "zonaHOMER"){
		$("#searchFormId").submit();
	}
	else{
		if (document.getElementsByName("q").length==1){
			window.location = '/catalogo/busqueda-libre/'+document.getElementsByName("q")[0].value;
		}
		else{
			window.location = '/catalogo/busqueda-libre/'+document.getElementsByName("q")[1].value;
		}
	}
	return false;
}


function utf8_encode(argString) {
  //  discuss at: http://phpjs.org/functions/utf8_encode/
  // original by: Webtoolkit.info (http://www.webtoolkit.info/)
  // improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
  // improved by: sowberry
  // improved by: Jack
  // improved by: Yves Sucaet
  // improved by: kirilloid
  // bugfixed by: Onno Marsman
  // bugfixed by: Onno Marsman
  // bugfixed by: Ulrich
  // bugfixed by: Rafal Kukawski
  // bugfixed by: kirilloid
  //   example 1: utf8_encode('Kevin van Zonneveld');
  //   returns 1: 'Kevin van Zonneveld'

  if (argString === null || typeof argString === 'undefined') {
    return '';
  }

  var string = (argString + ''); // .replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  var utftext = '',
    start, end, stringl = 0;

  start = end = 0;
  stringl = string.length;
  for (var n = 0; n < stringl; n++) {
    var c1 = string.charCodeAt(n);
    var enc = null;

    if (c1 < 128) {
      end++;
    } else if (c1 > 127 && c1 < 2048) {
      enc = String.fromCharCode(
        (c1 >> 6) | 192, (c1 & 63) | 128
      );
    } else if ((c1 & 0xF800) != 0xD800) {
      enc = String.fromCharCode(
        (c1 >> 12) | 224, ((c1 >> 6) & 63) | 128, (c1 & 63) | 128
      );
    } else { // surrogate pairs
      if ((c1 & 0xFC00) != 0xD800) {
        throw new RangeError('Unmatched trail surrogate at ' + n);
      }
      var c2 = string.charCodeAt(++n);
      if ((c2 & 0xFC00) != 0xDC00) {
        throw new RangeError('Unmatched lead surrogate at ' + (n - 1));
      }
      c1 = ((c1 & 0x3FF) << 10) + (c2 & 0x3FF) + 0x10000;
      enc = String.fromCharCode(
        (c1 >> 18) | 240, ((c1 >> 12) & 63) | 128, ((c1 >> 6) & 63) | 128, (c1 & 63) | 128
      );
    }
    if (enc !== null) {
      if (end > start) {
        utftext += string.slice(start, end);
      }
      utftext += enc;
      start = end = n + 1;
    }
  }

  if (end > start) {
    utftext += string.slice(start, stringl);
  }

  return utftext;
}

function utf8_decode(str_data) {
  //  discuss at: http://phpjs.org/functions/utf8_decode/
  // original by: Webtoolkit.info (http://www.webtoolkit.info/)
  //    input by: Aman Gupta
  //    input by: Brett Zamir (http://brett-zamir.me)
  // improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
  // improved by: Norman "zEh" Fuchs
  // bugfixed by: hitwork
  // bugfixed by: Onno Marsman
  // bugfixed by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
  // bugfixed by: kirilloid
  //   example 1: utf8_decode('Kevin van Zonneveld');
  //   returns 1: 'Kevin van Zonneveld'

  var tmp_arr = [],
    i = 0,
    ac = 0,
    c1 = 0,
    c2 = 0,
    c3 = 0,
    c4 = 0;

  str_data += '';

  while (i < str_data.length) {
    c1 = str_data.charCodeAt(i);
    if (c1 <= 191) {
      tmp_arr[ac++] = String.fromCharCode(c1);
      i++;
    } else if (c1 <= 223) {
      c2 = str_data.charCodeAt(i + 1);
      tmp_arr[ac++] = String.fromCharCode(((c1 & 31) << 6) | (c2 & 63));
      i += 2;
    } else if (c1 <= 239) {
      // http://en.wikipedia.org/wiki/UTF-8#Codepage_layout
      c2 = str_data.charCodeAt(i + 1);
      c3 = str_data.charCodeAt(i + 2);
      tmp_arr[ac++] = String.fromCharCode(((c1 & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
      i += 3;
    } else {
      c2 = str_data.charCodeAt(i + 1);
      c3 = str_data.charCodeAt(i + 2);
      c4 = str_data.charCodeAt(i + 3);
      c1 = ((c1 & 7) << 18) | ((c2 & 63) << 12) | ((c3 & 63) << 6) | (c4 & 63);
      c1 -= 0x10000;
      tmp_arr[ac++] = String.fromCharCode(0xD800 | ((c1 >> 10) & 0x3FF));
      tmp_arr[ac++] = String.fromCharCode(0xDC00 | (c1 & 0x3FF));
      i += 4;
    }
  }

  return tmp_arr.join('');
}
