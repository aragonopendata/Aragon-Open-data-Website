from ckan.tests.html_check import HtmlCheckMethods
from ckan.tests import TestController as ControllerTestCase

class FunctionalTestCase(ControllerTestCase, HtmlCheckMethods):
    pass
